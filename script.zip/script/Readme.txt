INSTAL VPS DEBIAN 7 

wget -O debian7.sh http://sshaiopremium.ga/script/debian7/debian7.sh && chmod +x debian7.sh && ./debian7.sh     ( DEBIAN 7 32/64 ) KVM & OVZ






INSTAL VPS CENTOS 6 

wget -O centos6-kvm.sh http://sshaiopremium.ga/script/centos6/centos6-kvm.sh && chmod +x centos6-kvm.sh && ./centos6-kvm.sh     ( CENTOS 6 32/64bit )  KVM

wget -O centos6-ovz.sh http://sshaiopremium.ga/script/centos6/centos6-ovz.sh && chmod +x centos6-ovz.sh && ./centos6-ovz.sh






UPDATE VPS

wget -O update http://sshaiopremium.ga/script/debian7/config/update && chmod +x update && ./update           ( DEBIAN 7 )

wget -O update http://sshaiopremium.ga/script/centos6/config/update && chmod +x update && ./update           ( CENTOS 6 )


OCS PANEL

wget -O ocspanel.sh http://sshaiopremium.ga/script/ocspanel/ocspanel.sh && chmod +x ocspanel.sh && ./ocspanel.sh