INSTAL VPS DEBIAN 7 

wget -O debian7.sh http://sshaiopremium.ga/script/debian7.sh && chmod +x debian7.sh && ./debian7.sh        ( DEBIAN 7 32 )


UPDATE VPS

wget -O update http://sshaiopremium.ga/aio/config/update && chmod +x update && ./update



